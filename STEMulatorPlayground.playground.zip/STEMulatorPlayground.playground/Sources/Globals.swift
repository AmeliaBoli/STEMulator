import Foundation

public enum GameState {
    case won
    case lost
    case completed
    case playAgain
    case unknown
}
